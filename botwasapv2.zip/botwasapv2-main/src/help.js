const help = (prefix) => {
	return `
┏━━❉ *About Bot* ❉━━┓
┣⊱ *${prefix}owner*
┣⊱ *${prefix}donasi*
┣⊱ *${prefix}info*
┣⊱ *${prefix}botstat*
┣⊱ *${prefix}bug*
┣━━❀ *Maker* ❀━━
┣⊱ *${prefix}ocr*
┣⊱ *${prefix}sticker*
┣⊱ *${prefix}tts*
┣⊱ *${prefix}toimg*
┣⊱ *${prefix}phlogo*
┣⊱ *${prefix}quotemaker*
┣⊱ *${prefix}ninjalogo*
┣⊱ *${prefix}glitch*
┣⊱ *${prefix}text3d*
┣━━❀ *Kerang ajaib* ❀━
┣⊱ *${prefix}kapankah*
┣⊱ *${prefix}apakah*
┣⊱ *${prefix}bisakah*
┣⊱ *${prefix}rate*
┣━━❀ *Fun* ❀━━━━
┣⊱ *${prefix}meme*
┣⊱ *${prefix}memeindo*
┣⊱ *${prefix}hilih*
┣⊱ *${prefix}fitnah*
┣⊱ *${prefix}truth*
┣⊱ *${prefix}dare*
┣⊱ *${prefix}bucin*
┣⊱ *${prefix}persengay*
┣━━❀ *Anime* ❀━━
┣⊱ *${prefix}loli*
┣⊱ *${prefix}nsfwloli*
┣⊱ *${prefix}anime*
┣⊱ *${prefix}randomanime*
┣⊱ *${prefix}randomhentai*
┣⊱ *${prefix}nsfwloli*
┣⊱ *${prefix}nsfwblowjob*
┣⊱ *${prefix}nsfwneko*
┣⊱ *${prefix}nsfwtrap*
┣━━❀ *Media* ❀━━
┣⊱ *${prefix}tiktokstalk*
┣⊱ *${prefix}ytmp4*
┣━━❀ *Other* ❀━━
┣⊱ *${prefix}ping*
┣⊱ *${prefix}shorturl*
┣⊱ *${prefix}fototiktok*
┣⊱ *${prefix}map*
┣⊱ *${prefix}kbbi*
┣⊱ *${prefix}artinama*
┣⊱ *${prefix}infogempa*
┣⊱ *${prefix}quotes*
┣⊱ *${prefix}cerpen*
┣⊱ *${prefix}lirik*
┣⊱ *${prefix}pokemon*
┣⊱ *${prefix}chord*
┣⊱ *${prefix}blocklist*
┣⊱ *${prefix}hidetag*
┣⊱ *${prefix}wolflogo*
┣⊱ *${prefix}lionlogo*
┣⊱ *${prefix}ssweb*
┣⊱ *${prefix}anjing*
┣⊱ *${prefix}indohot*
┣━━❀ *Group* ❀━━
┣⊱ *${prefix}linkgc*
┣⊱ *${prefix}tagall*
┣⊱ *${prefix}add* [+62xx]
┣⊱ *${prefix}group* [buka/tutup]
┣⊱ *${prefix}demote* [tag]
┣⊱ *${prefix}promote* [tag]
┣⊱ *${prefix}kick*
┣⊱ *${prefix}listadmin*
┣⊱ *${prefix}simih* [1/0]
┣⊱ *${prefix}nsfw* [1/0]
┣⊱ *${prefix}welcome* [1/0]
┣━━❀ *Owner bot* ❀━
┣⊱ *${prefix}clearall*
┣⊱ *${prefix}block*
┣⊱ *${prefix}unblock*
┣⊱ *${prefix}bc*
┣⊱ *${prefix}leave*
┣⊱ *${prefix}setpp*
┣⊱ *${prefix}setprefix*
┣━━━━━━━━━━━━━━
┃    *BOT BY AFFIS*
┗━━━━━━━━━━━━━━

`
}

exports.help = help

